{
    'name': 'Convive Web',
    'version': '17.0.1.0.0',
    'category': 'Website',
    'summary': 'Módulo web base para la aplicación ConVive',
    'author': 'Convive Team',
    'depends': ['base', 'web'],
    'data': [],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
