
package com.convive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConviveApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConviveApplication.class, args);
    }
}
